from regex_compiler import compileWithIgnoreCase

_FILTER_DIGIT = 'f(\d+?)'
_FILTER_LETTER = '([a-zA-Z][a-zA-Z0-9]*)'
_FILTER_DIGIT_AND_LETTER = _FILTER_DIGIT + _FILTER_LETTER
_FILTERS_OF_LAYER_FULL_REGULAR_EXPRESSION = r'' + _FILTER_DIGIT_AND_LETTER + '(-' + _FILTER_DIGIT_AND_LETTER + ')?(.*)?$'
_FILTER_PATTERN = compileWithIgnoreCase(_FILTERS_OF_LAYER_FULL_REGULAR_EXPRESSION)
def _getFilterMatch(layerName): return _FILTER_PATTERN.search(layerName)

_MAIN_FILTER_MATCH_GROUP = 1
_LETTER_OF_MAIN_FILTER_MATCH_GROUP = 2
_SECONDARY_FILTER_MATCH_GROUP = 4
_LETTER_OF_SECONDARY_FILTER_MATCH_GROUP = 5
_TEXT_AFTER_FILTERS_MATCH_GROUP = 6
DEFAULT_FILTER_VALUE = '0'
DEFAULT_SORTING_NUMBER = float('inf')
DEFAULT_SORTING_STRING = ''
def getSortedLayersByFilterNumberAndText(layers):
	def _keyFunction(layer):
		filterMatch = _getFilterMatch(layer.name)
		if filterMatch:
			mainFilter = int(filterMatch.group(_MAIN_FILTER_MATCH_GROUP))
			letterOfMainFilter = filterMatch.group(_LETTER_OF_MAIN_FILTER_MATCH_GROUP)
			secondaryFilter = int(filterMatch.group(_SECONDARY_FILTER_MATCH_GROUP) or DEFAULT_FILTER_VALUE)
			letterOfSecondaryFilter = filterMatch.group(_LETTER_OF_SECONDARY_FILTER_MATCH_GROUP) or DEFAULT_SORTING_STRING
			textAfterFilters = filterMatch.group(_TEXT_AFTER_FILTERS_MATCH_GROUP) or DEFAULT_SORTING_STRING
			return (mainFilter, secondaryFilter, letterOfMainFilter, letterOfSecondaryFilter, textAfterFilters)
		return (DEFAULT_SORTING_NUMBER, layer.name)
		
	return sorted(layers, key=_keyFunction)

def getFilterNumberOrNoneFromLayerName(layerName):
	filterMatch = _getFilterMatch(layerName)
	if not filterMatch: return None
	return int(filterMatch.group(_SECONDARY_FILTER_MATCH_GROUP) or filterMatch.group(_MAIN_FILTER_MATCH_GROUP))