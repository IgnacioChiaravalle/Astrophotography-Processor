import filters_manager

_FIRST_LAYER_INDEX = 0
def getShortestAndLongestWavelenghts(layers):
	return getLayerWavelengthOrDefault(layers[_FIRST_LAYER_INDEX].name), _getLongestWavelength(layers)

_INDEX_DECREMENT = 1
_DEFAULT_WAVELENGTH = int(filters_manager.DEFAULT_FILTER_VALUE)
def _getLongestWavelength(layers):
	wavelength = None
	inverseLayerIndex = len(layers) - _INDEX_DECREMENT
	while (not wavelength) and (inverseLayerIndex >= _FIRST_LAYER_INDEX):
		wavelength = filters_manager.getFilterNumberOrNoneFromLayerName(layers[inverseLayerIndex].name)
		inverseLayerIndex -= _INDEX_DECREMENT
		if wavelength: return wavelength
	return _DEFAULT_WAVELENGTH

def getLayerWavelengthOrDefault(layerName):
	wavelength = filters_manager.getFilterNumberOrNoneFromLayerName(layerName)
	if not wavelength: return _DEFAULT_WAVELENGTH
	return wavelength