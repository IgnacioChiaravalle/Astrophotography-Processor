from gimpfu import *

from filters_manager import DEFAULT_SORTING_NUMBER as _DEFAULT_FOR_MINIMUM
_DEFAULT_FOR_MAXIMUM = _INITIAL_OFFSET = 0

def equalizeLayerSizes(image, layers, scaleLayersToSmallest):
	standardWidth, standardHeight, offsetX, offsetY =_getStandardWidthAndHeightAndOffsets(layers, _compareForMinimum, _DEFAULT_FOR_MINIMUM) if scaleLayersToSmallest else _getStandardWidthAndHeightAndOffsets(layers, _compareForMaximum, _DEFAULT_FOR_MAXIMUM)
	_equalizeAllWidthsAndHeights(image, layers, standardWidth, standardHeight, offsetX, offsetY)

def _getStandardWidthAndHeightAndOffsets(layers, comparisonFunction, defaultWidthAndHeight):
	standardWidth = standardHeight = defaultWidthAndHeight
	startingX = startingY = _INITIAL_OFFSET
	for layer in layers:
		if comparisonFunction(layer.width, standardWidth):
			standardWidth = layer.width
			startingX, _ = pdb.gimp_drawable_offsets(layer)
		if comparisonFunction(layer.height, standardHeight):
			standardHeight = layer.height
			_, startingY = pdb.gimp_drawable_offsets(layer)
	return standardWidth, standardHeight, -startingX, -startingY

def _compareForMinimum(a, b): return a < b
def _compareForMaximum(a, b): return a > b

_SCALE_FROM_LOCAL_ORIGIN = True
def _equalizeAllWidthsAndHeights(image, layers, standardWidth, standardHeight, offsetX, offsetY):
	pdb.gimp_image_resize(image, standardWidth, standardHeight, offsetX, offsetY)
	for layer in layers:
		if layer.width != standardWidth or layer.height != standardHeight:
			pdb.gimp_layer_scale(layer, standardWidth, standardHeight, _SCALE_FROM_LOCAL_ORIGIN)
