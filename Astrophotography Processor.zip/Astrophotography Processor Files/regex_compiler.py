import re

def compileWithIgnoreCase(regex): return re.compile(regex, re.IGNORECASE)