from regex_compiler import compileWithIgnoreCase

_LEVELLED_REGULAR_EXPRESSION = r'LVLD'
_LEVELLED_PATTERN = compileWithIgnoreCase(_LEVELLED_REGULAR_EXPRESSION)
def layerIsLevelled(layerName):
	return True if _LEVELLED_PATTERN.search(layerName) else False
	