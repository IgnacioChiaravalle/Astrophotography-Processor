from regex_compiler import compileWithIgnoreCase
from filters_manager import DEFAULT_SORTING_STRING

_NEGATIVE_SIGN_MATCH_GROUP = 1
_INTEGER_PART_MATCH_GROUP = 2
_DECIMAL_PART_MATCH_GROUP = 3
_DEFAULT_NEGATIVE_SIGN = DEFAULT_SORTING_STRING
_DEFAULT_DECIMAL_PART = '.0'
_NUMBERS_IN_REGULAR_EXPRESSIONS = '(\d+)(\.\d+)?'

_HUE_REGULAR_EXPRESSION = r'HUE:(\b)' + _NUMBERS_IN_REGULAR_EXPRESSIONS
_HUE_PATTERN = compileWithIgnoreCase(_HUE_REGULAR_EXPRESSION)
MINIMUM_HUE = 0.0
MAXIMUM_HUE = 256.0
_DEFAULT_HUE = None
def getHueFromName(layerName):
	hueMatch = _HUE_PATTERN.search(layerName)
	if not hueMatch: return None
	return _getColorizationParameterFromName(hueMatch, MINIMUM_HUE, MAXIMUM_HUE, _DEFAULT_HUE)

_SATURATION_REGULAR_EXPRESSION = r'SAT:(\b)' + _NUMBERS_IN_REGULAR_EXPRESSIONS
_SATURATION_PATTERN = compileWithIgnoreCase(_SATURATION_REGULAR_EXPRESSION)
_MINIMUM_SATURATION = MINIMUM_HUE
_MAXIMUM_SATURATION = _DEFAULT_SATURATION = 100.0
def getSaturationFromName(layerName):
	return _getColorizationParameterFromName(_SATURATION_PATTERN.search(layerName), _MINIMUM_SATURATION, _MAXIMUM_SATURATION, _DEFAULT_SATURATION)

_LIGHTNESS_REGULAR_EXPRESSION = r'LIG:(-)?' + _NUMBERS_IN_REGULAR_EXPRESSIONS
_LIGHTNESS_PATTERN = compileWithIgnoreCase(_LIGHTNESS_REGULAR_EXPRESSION)
_MINIMUM_LIGHTNESS = -100.0
_MAXIMUM_LIGHTNESS = _MAXIMUM_SATURATION
_DEFAULT_LIGHTNESS = -50.0
def getLightnessFromName(layerName):
	return _getColorizationParameterFromName(_LIGHTNESS_PATTERN.search(layerName), _MINIMUM_LIGHTNESS, _MAXIMUM_LIGHTNESS, _DEFAULT_LIGHTNESS)

_OPACITY_REGULAR_EXPRESSION = r'OPA:(\b)' + _NUMBERS_IN_REGULAR_EXPRESSIONS
_OPACITY_PATTERN = compileWithIgnoreCase(_OPACITY_REGULAR_EXPRESSION)
_MINIMUM_OPACITY = MINIMUM_HUE
_MAXIMUM_OPACITY = _MAXIMUM_SATURATION
_DEFAULT_OPACITY = _DEFAULT_HUE
def getOpacityFromName(layerName):
	return _getColorizationParameterFromName(_OPACITY_PATTERN.search(layerName), _MINIMUM_OPACITY, _MAXIMUM_OPACITY, _DEFAULT_OPACITY)

def _getColorizationParameterFromName(match, minimumValue, maximumValue, defaultValue):
	if match:
		negativeSignPart = _getNegativeSignPart(match)
		integerPart = _getIntegerPart(match)
		decimalPart = _getDecimalPart(match)
		parameterFloat = float(negativeSignPart + integerPart + decimalPart)
		if minimumValue <= parameterFloat <= maximumValue: return parameterFloat
	return defaultValue

def _getNegativeSignPart(match):
	return match.group(_NEGATIVE_SIGN_MATCH_GROUP) or _DEFAULT_NEGATIVE_SIGN
def _getIntegerPart(match):
	return match.group(_INTEGER_PART_MATCH_GROUP)
def _getDecimalPart(match):
	return match.group(_DECIMAL_PART_MATCH_GROUP) or _DEFAULT_DECIMAL_PART