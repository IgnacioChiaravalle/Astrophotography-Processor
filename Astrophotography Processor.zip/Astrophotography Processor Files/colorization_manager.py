from gimpfu import *
import colorization_parameters_finder, wavelength_manager

_MINIMUM_HUE = colorization_parameters_finder.MINIMUM_HUE

_TOP_LAYERS_DEFAULT_OPACITY = 35.0
def makeFullLayerColorization(image, layer, shortestWavelength, wavelengthRange, mustRemoveBackground, isTopLayer):
	hueForLayer = _getHueForLayer(layer.name, shortestWavelength, wavelengthRange)
	_colorizeLayerWithHue(layer, hueForLayer)
	if isTopLayer and mustRemoveBackground:
		_removeLayerBackground(image, layer)
	layerOpacity = colorization_parameters_finder.getOpacityFromName(layer.name)
	if layerOpacity:
		_reduceLayerOpacity(layer, layerOpacity)
	elif isTopLayer:
		_reduceLayerOpacity(layer, _TOP_LAYERS_DEFAULT_OPACITY)

_MINUMUM_WAVELENGTH =_MINIMUM_HUE
_MAXIMUM_WAVELENGTH_PROPORTION = 1
def _getHueForLayer(layerName, shortestWavelength, wavelengthRange):
	hueFromLayerName = colorization_parameters_finder.getHueFromName(layerName)
	if hueFromLayerName:
		return hueFromLayerName
	adjustedLayerWavelenght = float(wavelength_manager.getLayerWavelengthOrDefault(layerName) - shortestWavelength)
	wavelengthRange = float(wavelengthRange)
	if (adjustedLayerWavelenght < _MINUMUM_WAVELENGTH) or (wavelengthRange == _MINUMUM_WAVELENGTH):
		return _MINIMUM_HUE
	wavelenghtProportionToRange = adjustedLayerWavelenght / wavelengthRange
	return colorization_parameters_finder.MAXIMUM_HUE * (_MAXIMUM_WAVELENGTH_PROPORTION - wavelenghtProportionToRange)

def _colorizeLayerWithHue(layer, hue):
	pdb.gimp_drawable_colorize_hsl(layer, hue, colorization_parameters_finder.getSaturationFromName(layer.name), colorization_parameters_finder.getLightnessFromName(layer.name))

_SELECT_COLOR_OPERATION = 0
_BACKGROUND_COLOR = (0, 0, 0)
def _removeLayerBackground(image, layer):
	pdb.gimp_layer_add_alpha(layer)
	pdb.gimp_image_select_color(image, _SELECT_COLOR_OPERATION, layer, _BACKGROUND_COLOR)
	pdb.gimp_drawable_edit_clear(layer)
	pdb.gimp_selection_none(image)

def _reduceLayerOpacity(layer, layerOpacity):
	pdb.gimp_layer_set_opacity(layer, layerOpacity)