#! /usr/bin/env python2
from gimpfu import *
import sys, os.path

_INDEX_OF_FIRST_POSITION = 0
_DIRECTORY_OF_IMPORTED_FILES = "Astrophotography Processor Files"
def _addDirectoryToSysPath(directoryName):
	currentFile = os.path.abspath(sys.argv[_INDEX_OF_FIRST_POSITION])
	currentDirectory = os.path.dirname(currentFile)
	targetDirectory = os.path.join(currentDirectory, directoryName)
	sys.path.insert(_INDEX_OF_FIRST_POSITION, targetDirectory)
_addDirectoryToSysPath(_DIRECTORY_OF_IMPORTED_FILES)

import filters_manager, layer_size_manager, wavelength_manager, manual_level_checker, colorization_manager

def _processAstrophotography(image, _, layerScaleMode, mustRemoveBackground):
	pdb.gimp_image_undo_group_start(image)
	_ensureRGBImageMode(image)
	sortedVisibleLayers = _sortLayers(image, _getVisibleLayers(image))
	layer_size_manager.equalizeLayerSizes(image, sortedVisibleLayers, layerScaleMode)
	_mapLayersToVisibleLight(image, sortedVisibleLayers, mustRemoveBackground)
	pdb.gimp_image_undo_group_end(image)

_RGB_BASE_TYPE = _INDEX_OF_FIRST_POSITION
def _ensureRGBImageMode(image):
	if pdb.gimp_image_base_type(image) != _RGB_BASE_TYPE: pdb.gimp_image_convert_rgb(image)

def _getVisibleLayers(image):
	visibleLayers = []
	for layer in image.layers:
		if layer.visible: visibleLayers.append(layer)
	return visibleLayers

def _sortLayers(image, layers):
	sortedLayers = filters_manager.getSortedLayersByFilterNumberAndText(layers)
	positionToReorder = len(image.layers) - 1
	for layer in sortedLayers: pdb.gimp_image_reorder_item(image, layer, None, positionToReorder)
	return sortedLayers

_MINIMUM_AMOUNT_OF_LAYERS = _LENGHT_REDUCTION = 1
def _mapLayersToVisibleLight(image, layers, mustRemoveBackground):
	if len(layers) >= _MINIMUM_AMOUNT_OF_LAYERS:
		shortestWavelength, longestWavelength = wavelength_manager.getShortestAndLongestWavelenghts(layers)
		wavelengthRange = longestWavelength - shortestWavelength
		for index, layer in enumerate(layers):
			if not manual_level_checker.layerIsLevelled(layer.name): pdb.gimp_drawable_levels_stretch(layer)
			isTopLayer = index < len(layers) - _LENGHT_REDUCTION
			colorization_manager.makeFullLayerColorization(image, layer, shortestWavelength, wavelengthRange, mustRemoveBackground, isTopLayer)

_RADIO_GROUP_DEFAULT = _MINIMUM_AMOUNT_OF_LAYERS
register(
	"python_fu_astrophotography_processor",
	"Convert FITS files into visible astrophotographical images.",

	"Using the \'Levels\' and \'Colorize\' features, this plug-in converts a given set of FITS files provided in various layers into a visible astrophotographical image.\n"
	+ "\n"
	+ "First, the image mode is set to RGB (if it isn't already). After that, layers are scaled to the size of the smallest or largest layer, according to the user's choice. Then, all visible layers are sorted by the wavelength their filters are able to capture, or alphabetically if no filter is found.\n"
	+ "\n"
	+ "At this point, layers are levelled. The user can add the \'LVLD\' tag (capitalization is optional) to a layer's name to indicate that said layer has been manually levelled and should not be automatically re-levelled by the plug-in.\n"
	+ "\n"
	+ "Finally, all visible layers are colorized according to the wavelength they represent.\n"
	+ "\n"
	+ "Users are able to decide whether the background of all layers but the bottom one will be removed or not. In addition, by editing the names of layers they can set values for the colorization process:\n"
	+ "- Adding \'HUE:X\' to the name of a layer allows the user to choose the hue for the colorization. X is a FLOAT, 0 <= X <= 256.\n"
	+ "- Adding \'SAT:Y\' to the name of a layer allows the user to choose the saturation for the colorization. Y is a FLOAT, 0 <= Y <= 100.\n"
	+ "- Adding \'LIG:Z\' to the name of a layer allows the user to choose the lightness for the colorization. Z is a FLOAT, -100 <= Z <= 100.\n"
	+ "- Adding \'OPA:W\' to the name of a layer allows the user to choose the final opacity of the layer. W is a FLOAT, 0 <= W <= 100.\n"
	+ "In all cases, capitalization is optional.\n",

	"Ignacio Chiaravalle", "Ignacio Chiaravalle, Universidad Nacional del Sur", "2024",
	"<Image>/Filters/Python-Fu Plug-Ins/Astrophotography...",
	"*",
	[
		(PF_RADIO, "layerScaleMode", "Which layer should define the size of the others?", _RADIO_GROUP_DEFAULT,
			(
				("Smallest one", True),
				("Largest one", False)
			)
		),
		(PF_BOOL, "mustRemoveBackground", "Should the background of top layers be removed?", False)
	],
	[],
	_processAstrophotography
)

main()